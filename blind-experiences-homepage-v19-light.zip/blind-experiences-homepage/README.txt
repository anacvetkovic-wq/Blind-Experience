Blind Experiences — homepage prototype (v19)

Open index.html in Chrome, Safari or Edge. Keep the "media" and "surprise" folders next to it.
An internet connection is needed for GSAP and the DM Sans font.
Interactive design prototype, not the live website.
